import React, {Component}from "react";
import './App.css';

import {
    BrowserRouter as Router,
    Route,
    Link,
    Switch
} from 'react-router-dom';
//header
import Header from './Components/headercomponent/header';
//footer
import Footer from './Components/footercomponent/footer';


//pages
import Home from './pages/homePage';
import Contact_Us from './pages/Contact_Us';
import pricing from './pages/pricing';
import about from './pages/about_us';



class App extends Component {

    render(){
        return(
            <Router>
                <div className="App">
                   <Header/>

                        <Switch>
                            <Route exact path='/' component={Home}></Route>
                            <Route exact path='/contact_us' component={Contact_Us}></Route>
                            <Route exact path='/pricing' component={pricing}></Route>
                            <Route exact path='/about' component={about}></Route>

                        </Switch>
                    <Footer/>
                </div>
            </Router>

        );
    }
}
export default App;



