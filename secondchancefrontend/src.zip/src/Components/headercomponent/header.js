import React, { Component } from 'react';
import './header.css';

class Header extends Component{
    render(){
        return (
            <header>
                <div className="logo">
                    LOGO
                </div>

                <nav>

                            <a href="/">Home</a>
                            <a href="/login">Login</a>
                            <a href="/account_register">Register</a>
                            <a href ="/pricing">Pricing</a>
                            <a href ="/about">Why Second Chance?</a>
                            <a href ="/contact_us">Contact Us</a>

                </nav>
            </header>
        )
    }
}

export default Header;