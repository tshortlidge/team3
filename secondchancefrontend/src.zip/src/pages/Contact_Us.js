import React from "react";



function Contact_Us()
    {


        return (


            <div>

                <h1>Contact Us</h1>
                <p>
                    Email us with any questions or inquiries or call (909)555-5555. We would be happy to answer your
                    questions
                    and set up a meeting with you. Second Chance can help! Hi, contact us at (909)555-5555! or by email
                    contactus@secondchance.com
                </p>
                <table>
                    <tr>
                        <td>
                            <div className={"contact-form"}>
                                <form action={"mailto:trevorshortlidge@gmail.com"} method={"post"}
                                      encType={"text/plain"} className={"form-control"}>
                                    <tr>
                                        <td>
                                            <label>Name: </label>
                                            <input type={"text"} name={"From "} className={"form-control"}/>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <label>Email: </label>
                                            <input type={"email"} name={"Recipient's Email "}
                                                   className={"form-control"}/>
                                        </td>
                                    </tr>


                                    <tr>
                                        <td>
                                            <label>Message: </label>
                                            <br/>
                                            <textarea name={"Message "} rows={"20"} cols={"100"}
                                                      className={"form-control"}></textarea>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>

                                            <input type={"submit"} name={""}/>

                                        </td>
                                    </tr>
                                </form>
                            </div>
                        </td>
                    </tr>
                </table>
            </div>
        );

    }





export default Contact_Us;