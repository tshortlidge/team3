import React from "react";
import doctor from '../pictures/doctorpicture.jpg'

function about_us() {


    return (

        <div>
            <div className="about-logo">
                <img src={doctor} alt="Doctor Image" />
            </div>
            <h1>About Us</h1>
            <p>
                We are a team of software engineers at CSUSB striving to make the best affortable alternative solution to
                finding medical care answers that you feel are incorrect or just want a second opinion.


            </p>

        </div>

    );

}

export default about_us;