import React, { Component } from 'react';


class Dummypage extends Component{
    render(){
        return(
            <dummypage>

                <p>You're on the Dummy Page!</p>
            </dummypage>
        );
    }
}
export default Dummypage;