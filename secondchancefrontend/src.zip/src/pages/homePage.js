import React from "react";


function homePage() {


        return (

            <div>

                <h1>Home Page</h1>
                <p>
                    Description: Patients take medical images such as CTs, MRIs, x-rays from different medical facilities.
                    They are scattered in different hospital databases. Create a central medical imaging database system where medical images can be uploaded by physicians from different hospitals.
                    Patients and their doctors are able to log in and view all the uploaded images. The system also provides a service to the patients to get their image interpreted for a fee.
                    It should allow the patients to view a list of radiologists with their bios and give them an option to choose which physician to interpret their image.


                </p>
            </div>

        );
}



export default homePage;